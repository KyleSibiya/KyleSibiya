# Pytest Unit Tests

## Install test dependencies

`pip install -r tests-units/requirements.txt`

## Run tests
`pytest tests-units/`
