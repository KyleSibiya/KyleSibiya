// Shim for scripts/logging.ts
export const ComfyLogging = window.comfyAPI.logging.ComfyLogging;
