// Shim for scripts/ui/spinner.ts
export const createSpinner = window.comfyAPI.spinner.createSpinner;
